import "./App.css";
import { useEffect, useState } from "react";

import AddTodo from "./components/AddTodo/AddTodo";
import TodoList from "./components/TodoList/TodoList";


function App() {
  // state stores all todos shown in the UI
  const [todos, setTodos] = useState([]);

  
  useEffect(() => {
    fetch("http://localhost:4000/todos")
      .then((res) => res.json())      // convert response to JSON
      .then((data) => setTodos(data)) // put todos into state
      .catch((err) => console.log("Error fetching todos:", err));
  }, []);

  
   //Add a todo and Sends POST request to backend. Backend inserts into SQLite and returns the created todo object
    //We update UI by adding the new todo to state
   
  function addTodo(title) {
    fetch("http://localhost:4000/todos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title: title }),
    })
      .then((res) => res.json())
      .then((newTodo) => {
        // Add to UI immediately (put new todo at the top)
        setTodos([newTodo, ...todos]);
      })
     .catch((err) => console.log("Error adding todo:", err));
  }

  //Toggles a todo (completed true/false): Sends PUT request to backend. Backend flips completed in SQLite and returns the updated todo
  //  We replace the matching todo in state
   
  function toggleTodo(id) {
    fetch("http://localhost:4000/todos/" + id, { method: "PUT" })
   .then((res) => res.json())
   .then((updatedTodo) => {
     const updatedList = todos.map((todo) =>
          todo.id === id ? updatedTodo : todo
        );
        setTodos(updatedList);
      })
  .catch((err) => console.log("Error updating todo:", err));
  }

  
   //Deletes a todo: Sends DELETE request to backend
   //Backend deletes from SQLite
   // We remove it from UI state
   
    function deleteTodo(id) {
     fetch("http://localhost:4000/todos/" + id, { method: "DELETE" })
      .then(() => {
        const filteredList = todos.filter((todo) => todo.id !== id);
        setTodos(filteredList);
      })
      .catch((err) => console.log("Error deleting todo:", err));
  }

  return (
    <div style={{ padding: 20, maxWidth: 600 }}>
      <h2>Todo App (React + Node + SQLite)</h2>

   <AddTodo onAdd={addTodo} />


      <TodoList todos={todos} onToggle={toggleTodo} onDelete={deleteTodo} />
    </div>
  );
}

export default App;
