import { useState } from "react";


function AddTodo(props) {
  // Local state just for the input box
  const [title, setTitle] = useState("");

  function handleSubmit(e) {
    e.preventDefault(); // stop page refresh

    // trim removes extra spaces
    const clean = title.trim();
    if (!clean) return; // don't add empty todo

    // Call the function passed from App
    props.onAdd(clean);

    // Clear input after add
    setTitle("");
  }

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: 12 }}>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Enter a todo..."
        style={{ padding: 8, width: 280 }}
      />

      <button type="submit" style={{ marginLeft: 8, padding: "8px 12px" }}>
        Add
      </button>
    </form>
  );
}

export default AddTodo;