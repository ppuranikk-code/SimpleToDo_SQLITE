
 //TodoItem component
 
function TodoItem({ todo, onToggle, onDelete }) {
  return (
    <li style={{ display: "flex", alignItems: "center", marginBottom: 10 }}>
  
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() => onToggle(todo.id)}
      />

      
      <span
        style={{
          marginLeft: 10,
          flex: 1,
          textDecoration: todo.completed ? "line-through" : "none",
          opacity: todo.completed ? 0.6 : 1,
        }}
      >
        {todo.title}
      </span>

    
      <button onClick={() => onDelete(todo.id)} style={{ padding: "6px 10px" }}>
        Delete
      </button>
    </li>
  );
}

export default TodoItem;