import TodoItem from "../TodoItem/TodoItem";


 //TodoList component
 
function TodoList({ todos, onToggle, onDelete }) {
  // If list is empty, show a friendly message
  if (!todos || todos.length === 0) {
    return <p>No todos yet. Add one!</p>;
  }

  return (
    <ul style={{ listStyle: "none", paddingLeft: 0 }}>
      {todos.map((todo) => (
        <TodoItem
          key={todo.id}       // key is required by React when mapping lists
          todo={todo}         // pass todo object
          onToggle={onToggle} // pass toggle function down
          onDelete={onDelete} // pass delete function down
        />
      ))}
    </ul>
  );
}

export default TodoList;