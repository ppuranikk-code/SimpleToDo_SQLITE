let app = require("./app");

const PORT = 4000;

app.listen(PORT, function () {
  console.log(`Server running on http://localhost:${PORT}`);
});