const path = require("path");
const sqlite3 = require("sqlite3").verbose();

// Database file lives in backend/ folder
const dbPath = path.join(__dirname, "todos.db");

// Open (or create) the database
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.log("DB connection error:", err.message);
    return;
  }

  console.log("Connected to SQLite DB:", dbPath);

  // Create table right after connecting
  db.run(`
    CREATE TABLE IF NOT EXISTS todos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      completed INTEGER NOT NULL DEFAULT 0
    )
  `, (err2) => {
    if (err2) console.log("Table create error:", err2.message);
    else console.log("Todos table ready");
  });
});


module.exports = db;
