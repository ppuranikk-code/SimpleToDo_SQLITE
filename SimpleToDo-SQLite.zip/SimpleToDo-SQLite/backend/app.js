let express = require("express");
let cors = require("cors");

let todoRoutes = require("./routing");

let app = express();

app.use(cors());
app.use(express.json());

// All todo routes live under /todos
app.use("/todos", todoRoutes);

module.exports = app;