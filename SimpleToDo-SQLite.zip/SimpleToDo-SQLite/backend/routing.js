const express = require("express");
const router = express.Router();
const db = require("./db");

// GET /todos  -> return all todos
router.get("/", function (req, res) {
  db.all("SELECT id, title, completed FROM todos ORDER BY id DESC", [], function (err, rows) {
    if (err) return res.status(500).json({ message: err.message });

    res.json(
      rows.map((r) => ({
        id: r.id,
        title: r.title,
        completed: Boolean(r.completed),
      }))
    );
  });
});

// POST /todos  -> add a todo
router.post("/", function (req, res) {
  const title = req.body.title;

  if (!title || typeof title !== "string" || title.trim() === "") {
    return res.status(400).json({ message: "title is required" });
  }

  const cleanTitle = title.trim();

  db.run(
    "INSERT INTO todos (title, completed) VALUES (?, 0)",
    [cleanTitle],
    function (err) {
      if (err) return res.status(500).json({ message: err.message });

      res.status(201).json({
        id: this.lastID,
        title: cleanTitle,
        completed: false,
      });
    }
  );
});

// PUT /todos/:id  -> toggle completed
router.put("/:id", function (req, res) {
  const id = Number(req.params.id);

  db.get("SELECT id, title, completed FROM todos WHERE id = ?", [id], function (err, row) {
    if (err) return res.status(500).json({ message: err.message });
    if (!row) return res.status(404).json({ message: "Todo not found" });

    const newCompleted = row.completed ? 0 : 1;

    db.run("UPDATE todos SET completed = ? WHERE id = ?", [newCompleted, id], function (err2) {
      if (err2) return res.status(500).json({ message: err2.message });

      res.json({
        id: row.id,
        title: row.title,
        completed: Boolean(newCompleted),
      });
    });
  });
});

// DELETE /todos/:id  -> delete
router.delete("/:id", function (req, res) {
  const id = Number(req.params.id);

  db.run("DELETE FROM todos WHERE id = ?", [id], function (err) {
    if (err) return res.status(500).json({ message: err.message });
    if (this.changes === 0) return res.status(404).json({ message: "Todo not found" });

    res.json({ message: "Todo deleted" });
  });
});

module.exports = router;